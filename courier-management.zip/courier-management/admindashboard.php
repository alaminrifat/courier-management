<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
</head>
<body>
    <ul type="none">
        <li><a href="manageemployee.php">Manage Employee</a></li>
        <li><a href="managedeliveryman.php">Manage Delivery Man</a></li>
        <li><a href="#">Manage Courier Hub</a></li>
        <li><a href="#">Parcel Cost Calculate</a></li>
        <li><a href="#">Get Report</a></li>

    </ul>
</body>
</html>